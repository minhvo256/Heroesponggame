package pongGame_nReq;

public enum MyDialogResult {
	YES,
	NO,
	CANCEL,
	DEFAULT
}
